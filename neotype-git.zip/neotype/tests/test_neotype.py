import os, sys, tempfile, unittest, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import neotype as nt

HERE = os.path.dirname(__file__)
EXAMPLE = os.path.join(HERE, "..", "examples", "example.nt")


def msgs(texto, **kw):
    _, errs, warns = nt.analizar(texto, **kw)
    return [m for _, m in errs], [m for _, m in warns]


class Format(unittest.TestCase):
    def test_blank_line_and_hyphen_start_class(self):
        cs, errs, _ = nt.analizar("- A\n- x: 1\n\n- B\n- y: 2\n")
        self.assertEqual([c.name for c in cs], ["A", "B"])
        self.assertEqual(errs, [])

    def test_blank_line_inside_body_does_not_end_class(self):
        t = "- A\n- f: () => {\nlet a = 1;\n\nreturn a;\n}\n"
        cs, errs, _ = nt.analizar(t)
        self.assertEqual(errs, [])
        self.assertEqual(len(cs), 1)
        self.assertIn("let a = 1;\n\nreturn a;", cs[0].props[0].value)

    def test_minus_inside_expression_is_not_property(self):
        cs, errs, _ = nt.analizar("- A\n- f: (x) => x - 1\n- g: (x) => x -\n1\n")
        self.assertEqual(errs, [])
        self.assertEqual(len(cs[0].props), 2)

    def test_crlf(self):
        cs, errs, _ = nt.analizar("- A\r\n- x: 1\r\n\r\n- B\r\n")
        self.assertEqual([c.name for c in cs], ["A", "B"])
        self.assertEqual(errs, [])

    def test_rejects_tabs_and_indentation(self):
        e, _ = msgs("- A\n- f: () => {\n\treturn 1;\n}\n")
        self.assertTrue(any("tabs" in m for m in e))
        e, _ = msgs("- A\n- f: () => {\n  return 1;\n}\n")
        self.assertTrue(any("indentation" in m for m in e))

    def test_maximum_line_width(self):
        e, _ = msgs("- A\n- x: " + "a" * 90 + "\n")
        self.assertTrue(any("columns" in m for m in e))

    def test_multiple_errors(self):
        self.assertTrue(msgs("hola\n- A\n")[0])                 # text outside
        self.assertTrue(msgs("- A\n- sin dos puntos\n")[0])     # missing ':'
        self.assertTrue(msgs("- A\n- x: 1\n- x: 2\n")[0])       # duplicate property
        self.assertTrue(msgs("- A\n\n- A\n")[0])                # duplicate class
        self.assertTrue(msgs("- A\n- f: () => {\n")[0])         # unclosed brace
        self.assertTrue(msgs("- A\n- extends: B\n\n- B\n- extends: A\n")[0])  # inheritance cycle
        self.assertTrue(msgs("- A\n- f: () =>\n")[0])           # empty body

    def test_external_extends_is_warning(self):
        e, w = msgs("- A\n- extends: Otra\n")
        self.assertEqual(e, [])
        self.assertTrue(w)


class Transpiler(unittest.TestCase):
    def js(self, t):
        cs, errs, _ = nt.analizar(t)
        self.assertEqual(errs, [])
        return nt.a_js(cs)

    def test_child_before_parent_is_reordered(self):
        js = self.js("- B\n- extends: A\n\n- A\n- x: 1\n")
        self.assertLess(js.index("class A"), js.index("class B"))

    def test_multiline_expression_avoids_asi(self):
        js = self.js("- A\n- f: () =>\n1 +\n2\n")
        self.assertIn("return (", js)
        self.assertEqual(nt.chequear_js(js), [])

    def test_function_forms(self):
        t = ("- A\n- a: x => x * 2\n- b: async (x) => await x\n"
             "- c: function(x) { return x; }\n- d: () => ({ k: 1 })\n"
             "- e: () => { return 1; };\n- static f: (x = g(1)) => x\n")
        js = self.js(t)
        r = nt.chequear_js(js)
        self.assertIn(r, ([], None))

    def test_json(self):
        cs, _, _ = nt.analizar("- A\n- x: 1\n- f: () => 2\n")
        d = nt.a_json(cs)[0]
        self.assertEqual(d["fields"], {"x": "1"})
        self.assertEqual(d["methods"], {"f": "() => 2"})


class Integration(unittest.TestCase):
    def test_example_runs(self):
        with open(EXAMPLE, encoding="utf-8") as source:
            cs, errs, _ = nt.analizar(source.read())
        self.assertEqual(errs, [])
        r = subprocess.run([sys.executable, os.path.join(HERE, "..", "scripts",
                            "neotype.py"), "run", EXAMPLE], capture_output=True, text=True)
        self.assertEqual(r.stdout.split("\n")[:3],
                         ["Rex says woof", "woof woof woof", "Mittens says meow"])

    def test_multi_page_pdf(self):
        t = "\n\n".join(
            f"- Clase{i}\n" + "\n".join(f"- m{j}: () => {j}" for j in range(12))
            for i in range(30))
        cs, errs, _ = nt.analizar(t)
        self.assertEqual(errs, [])
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "x.pdf")
            n = nt.a_pdf(cs, out, "x.nt")
            self.assertGreater(n, 1)
            self.assertTrue(os.path.getsize(out) > 1000)


if __name__ == "__main__":
    unittest.main()
