# neotype format (.nt)

## Grammar

```
file          = block ( BLANK_LINE+ block )*
block         = "- " NAME "\n" property*
property      = "- " KEY ":" VALUE "\n" continuation*
continuation  = (BLANK_LINE)* line_that_does_not_start_with("- ")
KEY           = ["static "] IDENTIFIER | "extends"
NAME          = IDENTIFIER
```

File-wide constraints: no tabs, no leading spaces, maximum 80 columns, and `\r\n` is normalized to `\n`.

## Property meanings

| Syntax | JavaScript output |
|---|---|
| `- extends: Animal` | `class X extends Animal` |
| `- name: "x"` | Class field `name = "x";` |
| `- name:` | Field without a value: `name;` |
| `- f: (a) => a * 2` | Method `f(a) { return (a * 2); }` |
| `- f: (a) => {` ... `}` | Method `f(a) {` ... `}` |
| `- f: x => x + 1` | Method with one unparenthesized parameter |
| `- f: async (a) => ...` | `async` method |
| `- f: function(a) {` ... `}` | Method (also supports `function*`) |
| `- static f: ...` | `static` method or field |
| `- constructor: (a) => {` ... `}` | Constructor (subclasses must call `super` inside it) |

Arrow functions are transpiled into methods, so `this` refers to the instance as expected.

## Edge cases

**A continuation line starting with `- `.** It is interpreted as a new property. Workarounds:

```
- f: (x) => x -
1
```

Or use `-1` / `-x` without a space.

**Blank lines inside a body.** A blank line does not end the class if the following line does not start with `- `. If a body needs a line starting with `- ` after a blank line, rewrite it.

**Multi-line arrow expressions.** They are wrapped in `return ( ... );` to avoid JavaScript automatic semicolon insertion issues.

**Multi-line template literals (backticks).** They are preserved as-is: the generated JS does not re-indent them.

**Inheritance.** File order does not matter: the generator places parent classes before child classes. An `extends` target not present in the file produces a warning (it is assumed to be external, e.g. `Error`). Inheritance cycles are errors.

## What `validate` checks

Tabs; leading indentation; lines longer than 80 columns; text outside a class; invalid class names; properties missing `:`; invalid keys; duplicate classes or properties; repeated or invalid `extends`; inheritance cycles; constructors that are not functions or are `static`; empty function bodies; unclosed parentheses, braces, or strings; and, if Node.js is installed, generated JavaScript syntax.

Known limitation: the bracket checker does not understand regex literals containing `(`, `[` or quotes.

## For datasets

`json` produces one object per class: `{"name", "extends", "fields": {...}, "methods": {...}}`. `static` properties retain the `static ` prefix in their keys. With `--jsonl`, one class is emitted per line, ready to load with standard tools.
