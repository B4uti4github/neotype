#!/usr/bin/env python3
"""neotype: indentation-free class pseudocode ( .nt files).

Format rules (summary):
  - A line starting with "- " (hyphen + space, column 0) opens a property.
  - A blank line followed by "- " opens a NEW CLASS.
  - Any other line continues the previous property (long bodies).
  - No tabs, no leading spaces, maximum 80 columns.

Commands:
  validate FILE            validates the format (and JS syntax if Node.js is available)
  js       FILE [-o OUT]   transpiles to JavaScript classes
  json     FILE [-o OUT]   exports to JSON (or JSONL with --jsonl)
  pdf      FILE [-o OUT]   exports a multi-page portrait A4 PDF
  run      FILE            transpiles and runs with Node.js (calls Main.main())
  build     FILE           validate + .js + .pdf
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field

MAX_COLS = 80
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
KEY = re.compile(r"^(static\s+)?([A-Za-z_$][\w$]*)$")


# --------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------
@dataclass
class Prop:
    key: str
    value: str
    line: int
    static: bool = False
    kind: str = "field"  # field | method


@dataclass
class Clase:
    name: str
    line: int
    extends: str = None
    props: list = field(default_factory=list)
    raw: list = field(default_factory=list)  # original lines (for PDF output)


# --------------------------------------------------------------------------
# JavaScript utilities (minimal scanner for brackets, strings, and comments)
# --------------------------------------------------------------------------
def brackets(s):
    """Returns ([(idx, char)], error) with brackets outside strings/comments."""
    out, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c in "'\"`":
            q = c
            i += 1
            while i < n and s[i] != q:
                if s[i] == "\\":
                    i += 1
                i += 1
            if i >= n:
                return out, f"unterminated {q} string"
        elif s.startswith("//", i):
            k = s.find("\n", i)
            i = n if k < 0 else k
            continue
        elif s.startswith("/*", i):
            k = s.find("*/", i + 2)
            if k < 0:
                return out, "unterminated /* comment"
            i = k + 2
            continue
        elif c in "([{)]}":
            out.append((i, c))
        i += 1
    return out, None


def balanceado(s):
    toks, err = brackets(s)
    if err:
        return err
    pila, pares = [], {")": "(", "]": "[", "}": "{"}
    for _, c in toks:
        if c in "([{":
            pila.append(c)
        else:
            if not pila or pila[-1] != pares[c]:
                return f"unmatched '{c}'"
            pila.pop()
    if pila:
        return f"unclosed '{pila[-1]}'"
    return None


def cierre(s, i):
    """Index of the closing bracket matching opener s[i], or -1."""
    toks, _ = brackets(s)
    prof = 0
    for idx, c in toks:
        if idx < i:
            continue
        prof += 1 if c in "([{" else -1
        if prof == 0:
            return idx
    return -1


def parse_funcion(v):
    """Recognizes JS arrow functions/functions. Returns (type, async, star, params, body), or None."""
    v = v.strip()
    m = re.match(r"(async\s+)?function\b\s*(\*)?\s*[\w$]*\s*", v)
    if m:
        rest = v[m.end():]
        if rest.startswith("("):
            c = cierre(rest, 0)
            if c > 0:
                body = rest[c + 1:].strip()
                if body.startswith("{"):
                    return ("function", bool(m.group(1)), bool(m.group(2)),
                            rest[1:c], body)
        return None
    m = re.match(r"(async\s+)?", v)
    asy, rest = bool(m.group(1)), v[m.end():]
    if rest.startswith("("):
        c = cierre(rest, 0)
        if c < 0:
            return None
        params, after = rest[1:c], rest[c + 1:].lstrip()
    else:
        m2 = re.match(r"([A-Za-z_$][\w$]*)\s*", rest)
        if not m2:
            return None
        params, after = m2.group(1), rest[m2.end():]
    if not after.startswith("=>"):
        return None
    return ("arrow", asy, False, params, after[2:].strip())


# --------------------------------------------------------------------------
# Parser + validation
# --------------------------------------------------------------------------
def analizar(text, max_cols=MAX_COLS):
    """Returns (classes, errors, warnings). Each issue is (line, message)."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    errs, warns, clases = [], [], []
    cur, last, blank, pending = None, None, False, 0

    for n, line in enumerate(text.split("\n"), 1):
        if "\t" in line:
            errs.append((n, "tabs are not allowed"))
        if line.strip() == "":
            if line != "":
                warns.append((n, "blank line contains whitespace"))
            if cur is not None:
                blank = True
                pending += 1
            continue
        if len(line) > max_cols:
            errs.append((n, f"{len(line)} columns (maximum {max_cols})"))
        if line[0] in " \t":
            errs.append((n, "leading indentation is not allowed"))

        if line.startswith("- "):
            rest = line[2:]
            if cur is None or blank:  # ---- new class
                name = rest.strip()
                if not IDENT.match(name):
                    errs.append((n, f"invalid class name: '{name}' "
                                    "(expected '- ClassName')"))
                cur = Clase(name, n, raw=[line])
                clases.append(cur)
                last = None
            else:  # ---- property
                cur.raw.append(line)
                if ":" not in rest:
                    errs.append((n, "property is missing ':' (expected '- key: value')"))
                    last = None
                else:
                    key, _, value = rest.partition(":")
                    key, value = key.strip(), value.strip()
                    if key == "extends":
                        if cur.extends:
                            errs.append((n, "duplicate 'extends' declaration in class"))
                        if not re.match(r"^[A-Za-z_$][\w$.]*$", value):
                            errs.append((n, f"invalid extends target: '{value}'"))
                        cur.extends = value
                        last = None
                    else:
                        m = KEY.match(key)
                        if not m:
                            errs.append((n, f"invalid key: '{key}'"))
                            last = None
                        else:
                            last = Prop(m.group(2), value, n, static=bool(m.group(1)))
                            cur.props.append(last)
            blank, pending = False, 0
        else:  # ---- continuation
            if cur is None:
                errs.append((n, "text outside a class (must start with '- ')"))
            elif last is None:
                errs.append((n, "continuation line has no preceding property"))
            else:
                cur.raw.extend([""] * pending)
                cur.raw.append(line)
                last.value += "\n" * (pending + 1) + line
            blank, pending = False, 0

    _verificar(clases, errs, warns)
    errs.sort()
    warns.sort()
    return clases, errs, warns


def _verificar(clases, errs, warns):
    nombres = {}
    for c in clases:
        if c.name in nombres:
            errs.append((c.line, f"duplicate class '{c.name}' (first defined on line "
                                 f"{nombres[c.name]})"))
        nombres.setdefault(c.name, c.line)

        vistos = {}
        for p in c.props:
            p.value = p.value.strip()
            f = parse_funcion(p.value)
            p.kind = "method" if f else "field"
            clave = (p.static, p.key)
            if clave in vistos:
                errs.append((p.line, f"duplicate property '{p.key}' in {c.name}"))
            vistos[clave] = p.line
            if p.key == "constructor":
                if not f:
                    errs.append((p.line, "'constructor' must be a function"))
                if p.static:
                    errs.append((p.line, "'constructor' cannot be static"))
            if f:
                body = f[4]
                if body in ("", ";"):
                    errs.append((p.line, f"'{p.key}' has an empty body"))
            e = balanceado(p.value)
            if e:
                errs.append((p.line, f"in '{p.key}': {e}"))

    for c in clases:
        if c.extends and c.extends not in nombres and "." not in c.extends:
            warns.append((c.line, f"{c.name} extends {c.extends}: is not defined "
                                  "in this file (assuming it is external)"))
    # ciclos
    for c in clases:
        visto, x = set(), c
        while x and x.extends in nombres:
            if x.name in visto:
                errs.append((c.line, f"inheritance cycle in '{c.name}'"))
                break
            visto.add(x.name)
            x = next(k for k in clases if k.name == x.extends)


# --------------------------------------------------------------------------
# JavaScript transpilation
# --------------------------------------------------------------------------
def reindentar(texto, base):
    """Indent generated JS (cosmetic only; .nt files are never indented)."""
    if "`" in texto:  # do not modify multi-line template literals
        return "\n".join(base + l if l else l for l in texto.split("\n"))
    depth, out = 0, []
    for l in texto.split("\n"):
        s = l.strip()
        if not s:
            out.append("")
            continue
        toks, _ = brackets(s)
        k = 0
        while k < len(s) and s[k] in ")]}":
            k += 1
        out.append(base + "  " * max(0, depth - k) + s)
        depth = max(0, depth + sum(1 if c in "([{" else -1 for _, c in toks))
    return "\n".join(out)


def _emitir(p):
    pre = "static " if p.static else ""
    if p.kind == "field":
        v = p.value.rstrip().rstrip(";").rstrip()
        return f"{pre}{p.key} = {v};" if v else f"{pre}{p.key};"
    tipo, asy, star, params, body = parse_funcion(p.value)
    pre += ("async " if asy else "") + ("*" if star else "")
    if tipo == "function":
        return f"{pre}{p.key}({params}) {body}"
    b = body.strip().rstrip(";").rstrip()
    if b.startswith("{") and cierre(b, 0) == len(b) - 1:  # braced body
        return f"{pre}{p.key}({params}) {b}"
    if "\n" in b or "//" in b:  # multi-line expression: avoid ASI issues
        return f"{pre}{p.key}({params}) {{\nreturn (\n{b}\n);\n}}"
    return f"{pre}{p.key}({params}) {{ return ({b}); }}"


def _ordenar(clases):
    por_nombre = {c.name: c for c in clases}
    orden, estado = [], {}

    def visitar(c):
        if estado.get(c.name) == 2:
            return
        if estado.get(c.name) == 1:
            raise ValueError(f"inheritance cycle in '{c.name}'")
        estado[c.name] = 1
        if c.extends in por_nombre:
            visitar(por_nombre[c.extends])
        estado[c.name] = 2
        orden.append(c)

    for c in clases:
        visitar(c)
    return orden


def a_js(clases, origen="design.nt", con_main=False):
    partes = [f"// Generated by neotype from {origen}. Do not edit manually.", ""]
    ordenadas = _ordenar(clases)
    for c in ordenadas:
        cab = f"class {c.name}" + (f" extends {c.extends}" if c.extends else "")
        cuerpo = [reindentar(_emitir(p), "  ") for p in c.props]
        if cuerpo:
            partes.append(cab + " {\n" + "\n\n".join(cuerpo) + "\n}")
        else:
            partes.append(cab + " {}")
        partes.append("")
    nombres = ", ".join(c.name for c in ordenadas)
    partes.append('if (typeof module !== "undefined" && module.exports) '
                  f"module.exports = {{ {nombres} }};")
    if con_main:
        partes.append('if (typeof Main !== "undefined" && '
                      'typeof Main.main === "function") Main.main();')
    return "\n".join(partes) + "\n"


# --------------------------------------------------------------------------
# JSON
# --------------------------------------------------------------------------
def a_json(clases):
    res = []
    for c in clases:
        campos, metodos = {}, {}
        for p in c.props:
            k = ("static " if p.static else "") + p.key
            (metodos if p.kind == "method" else campos)[k] = p.value
        res.append({"name": c.name, "extends": c.extends,
                    "fields": campos, "methods": metodos})
    return res


# --------------------------------------------------------------------------
# PDF (portrait A4, multi-page, monospaced, 80 columns)
# --------------------------------------------------------------------------
def _fuentes():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    pares = [
        ("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"),
        ("/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
         "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf"),
        ("/Library/Fonts/Courier New.ttf", "/Library/Fonts/Courier New Bold.ttf"),
        ("C:/Windows/Fonts/consola.ttf", "C:/Windows/Fonts/consolab.ttf"),
    ]
    for reg, bold in pares:
        if os.path.exists(reg) and os.path.exists(bold):
            pdfmetrics.registerFont(TTFont("NT-Mono", reg))
            pdfmetrics.registerFont(TTFont("NT-Mono-Bold", bold))
            return "NT-Mono", "NT-Mono-Bold", False
    return "Courier", "Courier-Bold", True  # solo latin-1


def a_pdf(clases, salida, titulo="neotype", cols=MAX_COLS, carta=False):
    from reportlab.lib.pagesizes import A4, letter
    from reportlab.pdfbase.pdfmetrics import stringWidth
    from reportlab.pdfgen import canvas

    reg, neg, latin1 = _fuentes()
    W, H = letter if carta else A4
    mx, mt, mb = 50, 50, 55
    size = min(10.0, (W - 2 * mx) / (cols * stringWidth("M", reg, 1)))
    lead = size * 1.3
    por_pagina = int((H - mt - mb) / lead)

    def limpio(t):
        return t.encode("latin-1", "replace").decode("latin-1") if latin1 else t

    bloques = []
    for c in clases:
        b = []
        for i, l in enumerate(c.raw):
            l = limpio(l)
            trozos = [l] if len(l) <= cols else \
                [l[k:k + cols - 1] + "\\" for k in range(0, len(l), cols - 1)]
            b.extend((t, i == 0) for t in trozos)
        bloques.append(b)

    paginas = [[]]
    for b in bloques:
        if paginas[-1] and len(b) <= por_pagina and len(b) > por_pagina - len(paginas[-1]):
            paginas.append([])  # keep a class together when it fits on one page
        for item in b:
            if len(paginas[-1]) >= por_pagina:
                paginas.append([])
            paginas[-1].append(item)
        if len(paginas[-1]) < por_pagina:
            paginas[-1].append(("", False))
    while len(paginas) > 1 and not any(t for t, _ in paginas[-1]):
        paginas.pop()

    cv = canvas.Canvas(salida, pagesize=(W, H))
    cv.setTitle(titulo)
    cv.setAuthor("neotype")
    total = len(paginas)
    for num, pag in enumerate(paginas, 1):
        cv.setFont(reg, 8)
        cv.setFillGray(0.4)
        cv.drawString(mx, H - 30, limpio(titulo))
        cv.drawRightString(W - mx, 28, f"{num}/{total}")
        cv.setFillGray(0)
        y = H - mt
        for texto, es_titulo in pag:
            cv.setFont(neg if es_titulo else reg, size)
            cv.drawString(mx, y, texto)
            y -= lead
        cv.showPage()
    cv.save()
    return total


# --------------------------------------------------------------------------
# Node
# --------------------------------------------------------------------------
def chequear_js(codigo):
    """Returns Node.js syntax errors, or None if Node.js is unavailable."""
    node = shutil.which("node")
    if not node:
        return None
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "check.cjs")
        with open(p, "w", encoding="utf-8") as f:
            f.write(codigo)
        r = subprocess.run([node, "--check", p], capture_output=True, text=True)
    if r.returncode == 0:
        return []
    lineas = [l for l in r.stderr.splitlines()
              if l.strip() and not l.startswith("Node.js v")]
    return lineas[:5]


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def _leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return f.read()


def _reportar(ruta, errs, warns):
    for n, m in warns:
        print(f"{ruta}:{n}: warning: {m}", file=sys.stderr)
    for n, m in errs:
        print(f"{ruta}:{n}: error: {m}", file=sys.stderr)


def _salida(args, ext):
    return args.output or os.path.splitext(args.file)[0] + ext


def main(argv=None):
    ap = argparse.ArgumentParser(prog="neotype", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for nombre in ("validate", "js", "json", "pdf", "run", "build"):
        s = sub.add_parser(nombre)
        s.add_argument("file")
        s.add_argument("-o", "--output")
        s.add_argument("--cols", type=int, default=MAX_COLS)
        if nombre == "json":
            s.add_argument("--jsonl", action="store_true")
        if nombre in ("pdf", "build"):
            s.add_argument("--letter", action="store_true", help="Letter size instead of A4")
    a = ap.parse_args(argv)

    clases, errs, warns = analizar(_leer(a.file), a.cols)
    base = os.path.basename(a.file)

    if a.cmd == "validate":
        _reportar(a.file, errs, warns)
        if errs:
            print(f"✗ {len(errs)} error(es)", file=sys.stderr)
            return 1
        r = chequear_js(a_js(clases, base))
        if r is None:
            print("warning: Node.js not found; JavaScript syntax check skipped",
                  file=sys.stderr)
        elif r:
            print("✗ generated JavaScript is invalid according to Node.js:", file=sys.stderr)
            print("\n".join("  " + l for l in r), file=sys.stderr)
            return 1
        print(f"✓ {base}: {len(clases)} class(es), valid format")
        return 0

    _reportar(a.file, errs, warns)
    if errs:
        print("✗ fix the errors before generating (neotype validate)", file=sys.stderr)
        return 1

    if a.cmd == "js":
        out = _salida(a, ".js")
        with open(out, "w", encoding="utf-8") as f:
            f.write(a_js(clases, base))
        print(out)
    elif a.cmd == "json":
        out = _salida(a, ".json" if not a.jsonl else ".jsonl")
        datos = a_json(clases)
        with open(out, "w", encoding="utf-8") as f:
            if a.jsonl:
                f.write("\n".join(json.dumps(d, ensure_ascii=False) for d in datos) + "\n")
            else:
                json.dump(datos, f, ensure_ascii=False, indent=2)
        print(out)
    elif a.cmd == "pdf":
        out = _salida(a, ".pdf")
        pags = a_pdf(clases, out, base, a.cols, a.letter)
        print(f"{out} ({pags} page(s))")
    elif a.cmd == "run":
        node = shutil.which("node")
        if not node:
            print("error: Node.js is not installed", file=sys.stderr)
            return 1
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "app.cjs")
            with open(p, "w", encoding="utf-8") as f:
                f.write(a_js(clases, base, con_main=True))
            return subprocess.run([node, p]).returncode
    elif a.cmd == "build":
        r = chequear_js(a_js(clases, base))
        if r:
            print("✗ generated JavaScript is invalid according to Node.js:", file=sys.stderr)
            print("\n".join("  " + l for l in r), file=sys.stderr)
            return 1
        raiz = os.path.splitext(a.file)[0]
        with open(raiz + ".js", "w", encoding="utf-8") as f:
            f.write(a_js(clases, base))
        pags = a_pdf(clases, raiz + ".pdf", base, a.cols, a.letter)
        print(f"{raiz}.js\n{raiz}.pdf ({pags} page(s))")
    return 0


if __name__ == "__main__":
    sys.exit(main())
